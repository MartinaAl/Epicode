import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

data = pd.read_csv("./analisi_pulite.csv")

# Analisi delle differenze di costo tra regioni utilizzando un boxplot
plt.figure(figsize=(12, 8))
sns.boxplot(x='region', y='charges', data=data, palette='viridis')
plt.title('Differenze di costo tra regioni')
plt.xlabel('Regione')
plt.ylabel('Spese mediche')
plt.savefig("Costi_per_regioni.png")
plt.show()
