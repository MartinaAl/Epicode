import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

# carico il dataset
data = pd.read_csv("./insurance.csv")

# Rimuovo le righe con valori mancanti
data = data.dropna()

# Sostituisco i valori mancanti con un valore specifico
data = data.fillna(0)

# Rimuovo duplicati
data = data.drop_duplicates()

# Salvo il dataset pulito
data.to_csv('analisi_pulite.csv', index=False)

# calcolo il numero di persone sottopeso
persone_sottopeso = data[(data['bmi'] <= 18.5)]["sex"].value_counts()
print("Le persone sottopeso sono:", persone_sottopeso)

# calcolo il numero di persone normopeso 
persone_normopeso = data[(data['bmi'] > 18.5) & (data['bmi'] <= 24.9)]["sex"].value_counts()
print ("Le persone normopeso sono: ", persone_normopeso)

# calcolo il numero di persone in sovrappeso suddivise per genere 
persone_sovrappeso = data[(data['bmi'] >= 25) & (data['bmi'] <= 29.9)]["sex"].value_counts()
print(persone_sovrappeso)

# lo stesso calcolo per le persone obese
persone_obese = data[(data['bmi'] >= 30) & (data['bmi'] <= 34.9)]["sex"].value_counts()
print(persone_obese)

# ed infine per le persone severamente obese
persone_severamente_obese = data[(data['bmi'] >= 35)]["sex"].value_counts()
print(persone_severamente_obese)


# Creazione dei subplot
fig, axs = plt.subplots(1, 5, figsize = (12, 6), sharex = True, sharey = True, constrained_layout = False)

# Definizione dei colori per sesso
colori = {"male": "blue", "female": "pink"}

# Grafico a torta per le persone sottopeso
axs[0].pie(persone_sottopeso, autopct = '%1.1f%%', startangle=90, colors=[colori[sex] for sex in persone_sottopeso.index])
axs[0].set_title("Persone sottopeso")

# Grafico a torta per le persone normopeso
axs[1].pie(persone_normopeso, autopct='%1.1f%%', startangle=90, colors=[colori[sex] for sex in persone_normopeso.index])
axs[1].set_title("Persone normopeso")

# Grafico a torta per le persone sovrappeso
axs[2].pie(persone_sovrappeso, autopct='%1.1f%%', startangle=90, colors=[colori[sex] for sex in persone_sovrappeso.index])
axs[2].set_title('Persone sovrappeso')

# Grafico a torta per le persone obese
axs[3].pie(persone_obese, autopct='%1.1f%%', startangle=90, colors=[colori[sex] for sex in persone_obese.index])
axs[3].set_title('Persone obese')

# Grafico a torta per le persone severamente obese
axs[4].pie(persone_severamente_obese, autopct='%1.1f%%', startangle=90, colors=[colori[sex] for sex in persone_severamente_obese.index])
axs[4].set_title('Persone severamente obese')

# Aggiungo legenda

fig.tight_layout() 
fig.subplots_adjust (bottom = 0.1)
plt.legend(colori.keys(), loc = "lower center", ncol = 6)
plt.savefig('Percentuale_bmi_per_sesso.png')
plt.savefig("BMI_per_genere.png")
plt.show()




